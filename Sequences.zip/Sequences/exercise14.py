user_input = input("Please enter three numbers: \t")

user_split = user_input.split(",")
print(user_split)

# convert the tokens into integers
int_tokens = []
for st in user_split:
    int_tokens.append(int(st))

# calculate the result: a + b - c
a, b, c = int_tokens
result = a + b - c

print(result)