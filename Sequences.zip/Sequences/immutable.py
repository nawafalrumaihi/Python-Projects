# result = True
# another_result = result
# print(id(result))
# print(id(another_result))
# print("*" * 10)
# result = False
# print(id(result))

result = "Correct"
another_result = result
print(id(result))
print(id(another_result))
print("*" * 10)
result += "ish"
print(id(result))
print(id(another_result))