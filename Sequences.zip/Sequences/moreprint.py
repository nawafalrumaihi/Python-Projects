name = "Nawaf"
age = 28

print(name, age, "Python", 2023)
print((name, age, "Python", 2023))

